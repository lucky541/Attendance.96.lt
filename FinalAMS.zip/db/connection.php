<?php
  
  $dbConnection = new mysqli('mysql.hostinger.in','u135339779_lucky','ssssssssss','u135339779_ams');
  
  if($dbConnection->connect_error){
      die($dbConnection->connect_error);
  }else{
    
  }

?>
