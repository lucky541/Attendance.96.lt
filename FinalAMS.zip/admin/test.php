<?php
 $arr= array();
 $i=1;
 while ($i<10) {
  $arr[$i]=$i;
  $i=$i+1;
 }
 echo $arr[1];
?>