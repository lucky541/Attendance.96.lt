# Attendance.96.lt
AMS is the final year project.it is capable in active management of attendance.

![alt tag](http://attendance.96.lt/img/ams.png "Attendance.96.lt")
