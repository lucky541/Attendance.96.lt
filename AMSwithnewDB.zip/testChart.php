
    <!--Feature 3 -->
      <div class="col-sm-4 text-xs-center hoverable"><br />
        <h3 class="h3-responsive"><i class="fa fa-mobile fa-5x" aria-hidden="true"></i></h3>
          
          <strong class="lead">Mobile</strong>
          <p >bla bla bla bla blabla bla bla bla blabla bla bla bla blabla bla bla bla bla
          bla bla bla bla blabla bla bla bla blabla bla bla bla bla
          bla bla bla bla blabla bla bla bla bla </p><br />
      </div><!--/Feature 3 -->


<?php
 include 'PieChart.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>charts</title>
	 <meta name="viewport" content="width=device-width,initial-scale=1"/>

  <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css"> 

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">

</head>
<body>
  <?php 
     printPieChart(20,12);
   ?>

</body>
<!-- SCRIPTS Starts
   <!-- JQuery -->
    <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>

    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="js/tether.min.js"></script>

    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="js/mdb.min.js"></script>

    

 <!-- SCRIPTS Starts -->
   <!-- JQuery -->
    <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>

    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="js/tether.min.js"></script>

    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="js/mdb.min.js"></script>

<script type="text/javascript">
	

</script>
</html>