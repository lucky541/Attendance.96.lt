
        <div class="hoverable">
            <!--First column-->
                        <center>
                            <!--Second column-->
                            <div class=" animated slideInRight hideoverflow">
                            <!--Carousel Wrapper-->
                            <div id="carousel-example-2"  class="carousel slide  "  data-ride="carousel">
                            <!--Indicators-->
                            <ol class="carousel-indicators" >
                            <li data-target="#carousel-example-2" data-slide-to="0" class="active dottes"></li>
                            <li data-target="#carousel-example-2" data-slide-to="1" class="dottes"></li>
                            <li data-target="#carousel-example-2" data-slide-to="2" class="dottes"></li>
                            <li data-target="#carousel-example-2" data-slide-to="3" class="dottes"></li>
                            </ol>
                            <!--/.Indicators-->

                               
<!--Slides-->
<div class="carousel-inner" role="listbox">
  
  <div class="carousel-item active ">
                <!--Card-->
            <div class="card  "  >
            <center>  <!--Card image--> 
            <div class=" overlay hm-white-slight ">
            <img src="img/ams/ams4sm.jpg" class="img-fluid" alt=""> 
            <a href="#">
            <div class="mask"></div>
            </a>
            </div> 
            <!--/.Card image-->
            <!--Card content-->
            <div class="card-block">
            <!--Title-->
            <h4 class="card-title"><b>Fast</b></h4>
            <!--Text--><hr />
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
           </div>
            <!--/.Card content-->
            </center>
            <br /> <br />
            </div>
            <!--/.Card-->
  </div>
            
  <div class="carousel-item">
             <!--Card-->
            <div class="card  "  >
           <center>  <!--Card image--> 
            <div class=" overlay hm-white-slight">
            <img src="img/ams/ams4sm.jpg" class="img-fluid" alt=""> 
            <a href="#">
            <div class="mask"></div>
            </a>
            </div> 
            <!--/.Card image-->
            <!--Card content-->
            <div class="card-block">
            <!--Title-->
            <h4 class="card-title"><b>Mobile Accessible</b></h4>
            <!--Text--><hr />
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
           </div>
            <!--/.Card content-->
            </center>
            <br /> <br />
            </div>
            <!--/.Card-->
 </div>
      
                
  <div class="carousel-item">
         <!--Card-->
            <div class="card "  >
             <center>  <!--Card image--> 
            <div class=" overlay hm-white-slight">
            <img src="img/ams/ams4sm.jpg" class="img-fluid" alt=""> 
            <a href="#">
            <div class="mask"></div>
            </a>
            </div> 
            <!--/.Card image-->
            <!--Card content-->
            <div class="card-block">
            <!--Title-->
            <h4 class="card-title"><b>Rich UI</b></h4>
            <!--Text--><hr />
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
           </div>
            <!--/.Card content-->
            </center>
            <br /> <br />
            </div>
            <!--/.Card-->
   
 </div>

            
  <div class="carousel-item">
         <!--Card-->
            <div class="card "  >
            <center>  <!--Card image-->
            <div class=" overlay hm-white-slight">
            <img src="img/ams/ams4sm.jpg" class="img-fluid" alt=""> 
            <a href="#">
            <div class="mask"></div>
            </a>
            </div> 
            <!--/.Card image-->
            <!--Card content-->
            <div class="card-block">
            <!--Title-->
            <h4 class="card-title"><b>Secure</b></h4>
            <!--Text--><hr />
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
           </div>
            <!--/.Card content-->
            </center>
            <br /> <br />
            </div>
            <!--/.Card-->
       </div>
    </div>

                                
<!--Controls-->
<a class="left carousel-control side" href="#carousel-example-2" role="button" data-slide="prev" >
<span class="icon-prev " aria-hidden="true"></span>
<span class="sr-only">Previous</span>
</a>
<a class="right carousel-control side" href="#carousel-example-2" role="button" data-slide="next">
<span class="icon-next" aria-hidden="true"></span>
<span class="sr-only">Next</span>
</a>
<!--/.Controls-->
                            </div>
                            <!--/.Carousel Wrapper-->
                        </div>
                        <!--/Second column-->
                        </center>
     </div> <!-- row div ends here-->
      <br />
       <br />
  