  $(function(){
                $(".addBtn").click(funtion(){
                alert()
            })
           })